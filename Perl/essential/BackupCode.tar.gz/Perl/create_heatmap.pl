#!/usr/bin/perl

use strict; use warnings; use Getopt::Std; use R_toolbox; use mitochy; use Algorithm::KMeans; use Thread; use Thread::Queue;
use vars qw($opt_z $opt_d $opt_r $opt_t $opt_s $opt_n $opt_b $opt_c);
getopts("z:d:rts:nbc:");

die "
usage: $0 [options] <Data Files>

Options:
-t: Test input correctness (e.g. color/break - not creating anything)
-r: Toggle to create image
-n: Don't trim image
-d: Directory of output file (string)
-m: Manipulate input with another input tsv (sum/min/average)
-z: Cluster file containing list of names/id at first column (tab separated)
-c: Color set input
-b: If less than ncol, put -100 (black boxes)
-s: Sort options (default: Descending)
    -s 0: Don't sort
    -s 1: Ascending
    -s 2: Not implemented

Whether there are data on second, third, fourth, etc does not matter
But make sure name of cluster and name in data files are the same
Example:
NAME	1	425	6
NAME2	2414125,662

Output:
1. <directory>/<name>.sorted: Contain sorted gene list
2. <directory>/<name>.png: PNG image if -r is on

" unless @ARGV;

die "Cannot have -s 0 and -c at the same time!\n" if defined($opt_s) and $opt_s == 0 and defined($opt_z);

my @dataFiles = @ARGV;
my $directory = defined($opt_d) ? $opt_d : "./";
mkdir $directory if not -d $directory;
my $clusterFile = $opt_z if defined($opt_z);
foreach my $dataFile (@dataFiles) {
	print "Processing $dataFile\n";
	my $outName = mitochy::getFilename($dataFile);
	$outName = $directory . "/" . $outName;
	main($dataFile, $outName);
}

sub main {
	my ($dataFile, $outName) = @_;
	my $Rscript;

	# Get colors and breaks from input	
	my $colors = get_colors($dataFile);
	my $breaks = get_breaks($dataFile);

	exit if ($opt_t);	
	# Get heatmap data
	my ($data, $ncol) = process_heatmapFile($dataFile);
	my %data = %{$data};
		
	if (defined($opt_s) and $opt_s == 2) {
		for (my $i = 2; $i <= $ncol+1; $i++) {
			my $command = "cut -f1,$i $dataFile > $dataFile.tmp$i";
			system($command);
		}
	}

	$clusterFile = $dataFile if defined($opt_s) and $opt_s == 0;
	my ($clusterNameArr, $clusterNameHash) = get_cluster($clusterFile) if defined($clusterFile);
	
	
	# Sort heatmap (either by clusterFile or high-low) and put into R data format, 
	# Get number of row, and number of column
	my ($Rdata, $Rnames, $RdataBig, $nrow) = sort_heatmap(\%data, $clusterNameHash, $clusterNameArr, $clusterFile, $outName, $ncol, $dataFile);

	#my @Rdata = split("\n", $Rdata);
	#for (my $i = 0; $i < @Rdata; $i++) {
	#	my ($name, $data) = $Rdata[$i] =~ /^(.+)(<-.+)$/;
	#	$name =~ tr/\!\@\#\$\%\^\&\*\(\)\-\+\=\/\?\>\<\,\/ /____________________/;
	#	$Rdata[$i] = "$name$data";
	#}
	#$Rnames =~ tr/\!\@\#\$\%\^\&\*\(\)\-\+\=\/\?\>\<\,\/ /____________________/;
	#$RdataBig =~ tr/\!\@\#\$\%\^\&\*\(\)\-\+\=\/\?\>\<\,\/ /____________________/;

	
	# Create R script
	$Rscript .= "

	library(GMD);
	library(RColorBrewer);
	
	# All Data
	$Rdata
	
	# Names
	$Rnames
	
	# Sample
	# sample <- c(name1, name2, etc)
	$RdataBig
	# Combined Data into Matrix
	dm <- matrix(c(sample), ncol=$ncol, nrow=$nrow, byrow=TRUE)
	
	# Histogram
	#hist <- c(sample)
	#h = hist(hist)
	#h\$breaks
	#h\$counts
	
	# PDF output
	pdf(\"$outName.pdf\", compress=TRUE)
	#png(\"$outName\.png\", res=300, width=200, height=2500)
	
	# Row names
	rownames(dm) = name
	
	# Colors
	mycol=function(x) {$colors}
	
	# Heatmap
	MIN = min(dm,na.rm=TRUE)
	MAX = max(dm,na.rm=TRUE)

	h <- heatmap.3(
	dm,
	Rowv=FALSE,
	Colv=FALSE,
	key=FALSE,
	main=NA,
	dendrogram=\"none\",
	cluster.by.row=FALSE,
	cluster.by.col=FALSE,
	labRow=FALSE,
	labCol=FALSE,
	na.color=\"grey\",
	breaks=$breaks,
	plot.row.partition = FALSE,
	color.FUN = mycol,
	mapsize=11.5	
	)
	
	";

	if (defined($opt_n)) {
		$Rscript =~ s/labRow=FALSE/labRow=TRUE/;
	}

	open (my $out, ">", "$outName.R") or die "Cannot write to $outName.R: $!\n";
	print $out $Rscript;
	close $out;
	if ($opt_r) {
		system("R --no-save < $outName.R > dump 2>&1") == 0 or die "Failed to run R script $outName.R: $!\n";
		unlink "$outName.R";
		my $cmd = "convert -density 400 $outName.pdf -trim -quality 100 -depth 8 $outName.png > /dev/null 2>&1";
		system($cmd);
		#system("convert -trim $outName.png $outName.tmp") if not defined($opt_n);
		#system("mv $outName.tmp $outName.png") if not defined($opt_n);
		#compress_pdf_to_png($outName);
		#unlink "$outName.pdf";
	}
}

sub get_colors {
	my ($input) = @_;
	my $colorset = defined($opt_c) ? $opt_c : $input;
	my $colors;
	$colors = "c(brewer.pal(9,\"Reds\"))" if $colorset =~ /H3K4me1/i;
	#$colors = "c(brewer.pal(9,\"Oranges\"))" if $colorset =~ /H3K4me3/i;
	$colors = "c(brewer.pal(9,\"Oranges\"))" if $colorset =~ /H3K27me3/i;
	$colors = "c(brewer.pal(9,\"Reds\"))" if $colorset =~ /H3K36me3/i;
	$colors = "c(brewer.pal(9,\"Reds\"))" if $colorset =~ /H3K9me3/i;
	$colors = "c(brewer.pal(9,\"Reds\"))" if $colorset =~ /H3K9ac/i;
	$colors = "c(brewer.pal(9,\"Greens\"))" if $colorset =~ /RNA/i;
	$colors = "c(brewer.pal(9,\"Purples\"))" if $colorset =~ /DRIP/i;
	$colors = "c(brewer.pal(9,\"Reds\"))" if $colorset =~ /DRIPc/i;
	$colors = "c(brewer.pal(9,\"Blues\"))" if $colorset =~ /CpG/i or $colorset =~ /dens/i;
	$colors = "c(brewer.pal(9,\"Greens\"))" if $colorset =~ /GC/i or $colorset =~ /cont/i;
	$colors = "c(rev(brewer.pal(11,\"RdBu\")))" if $colorset =~ /SKEW/i;
	#$colors = "c(\"\#d1e5f0\",\"\#f7f7f7\",\"\#fddbc7\",\"\#f4a582\",\"\#d6604d\",\"\#b2182b\",\"\#67001f\")" if $colorset =~ /SKEW/i;
	$colors = "c(rev(brewer.pal(12,\"RdBu\")))" if $colorset =~ /H3K4me3/i;
	$colors = "c(brewer.pal(9,\"Reds\"))" if $colorset =~ /RRBS/i or $colorset =~ /meth/i;
	#$colors = "c(brewer.pal(9,\"Reds\"))" if $colorset =~ /WGBS/i or $colorset =~ /meth/i;
	#$colors = "c(rev(brewer.pal(12,\"RdBu\")))" if $colorset =~ /RRBSMIN/i;
	$colors = "c(brewer.pal(9,\"Reds\"))" if $colorset =~ /GROSEQ/i;
	$colors = "c(\"white\",\"black\")" if $colorset =~ /hy\w+_pos/i;
	$colors = "c(rev(brewer.pal(9,\"RdBu\")))" if $colorset =~ /RDBU/i;
	$colors = "c(brewer.pal(9,\"Greens\"))" if $colorset =~ /GREENS/i;
	$colors = "c(brewer.pal(9,\"Oranges\"))" if $colorset =~ /ORANGES/i;
	$colors = "c(\"white\",\"black\")" if $colorset =~ /hy\w+_pos/i;
	$colors = "c(\"white\",\"black\")" if $colorset =~ /hy\w+_pos/i;
	$colors = "c(brewer.pal(9,\"Reds\"))" if $colorset =~ /snoRNA/i;
	if (not defined($colors)) {
		print "Colors of colorset $colorset undefined: Using default (RdBu)\n";
		$colors = "c(rev(brewer.pal(11,\"RdBu\")))";
	}
	return($colors);
}

sub get_breaks {
	my ($input) = @_;
	my $breakset = defined($opt_c) ? $opt_c : $input;
	my $breaks;
		$breaks = "c(0,		11,	22,	33,	44,	55,	66,	77,	88,	99)" if $breakset =~ /RDBU/i;
		$breaks = "c(0,		11,	22,	33,	44,	55,	66,	77,	88,	99)" if $breakset =~ /GREENS/i;
		$breaks = "c(0,		11,	22,	33,	44,	55,	66,	77,	88,	99)" if $breakset =~ /ORANGES/i;
		$breaks = "c(0,		20,	40,	60,	80,	100,	120,	140,	160,	MAX)" if $breakset =~ /DRIP/i;
		$breaks = "c(0,		5,	10,	15,	20,	25,	30,	35,	40,	MAX)" if $breakset =~ /DRIPc/i;
		$breaks = "c(0,		0.15,	0.3,	0.45,	0.6,	0.75,	0.9,	1.05,	1.2,	MAX)" if $breakset =~ /CPG/i or $breakset =~ /dens/i;
		$breaks = "c(0,		0.1,	0.2,	0.3,	0.4,	0.5,	0.6,	0.7,	0.8,	MAX)" if $breakset =~ /GC/i or $breakset =~ /cont/i;
		$breaks = "c(MIN,	1,	2.5,	5,	7.5,	10,	12.5,	15,	17.5,	MAX)" if $breakset =~ /H3K27me3/i;
		$breaks = "c(MIN,	1,	2.5,	5,	7.5,	10,	12.5,	15,	17.5,	MAX)" if $breakset =~ /H3K36me3/i;
		$breaks = "c(MIN,	1,	2.5,	5,	7.5,	10,	12.5,	15,	17.5,	MAX)" if $breakset =~ /H3K9me3/i;
		$breaks = "c(MIN,	1,	5,	10,	15,	20,	25,	30,	35,	MAX)" if $breakset =~ /H3K9ac/i;
		$breaks = "c(MIN,	10,	20,	30,	40,	50,	60,	70,	80,	MAX)" if $breakset =~ /RNA/i;
		$breaks = "c(1,		2,	4,	6,	8,	10,	12,	14,	16,	MAX)" if $breakset =~ /H3K4me1/i;
	        $breaks = "c(MIN, 	-0.2,	-0.15,	-0.1,	-0.05,	-0.01,	0.01,	0.05,	0.1,	0.15,	0.2,	MAX)" if $breakset =~ /SKEW/i;
	        $breaks = "c(-99999,	-100	,-75,	-50,	-25,	-0.000001,0.000001,25,	50,	75,	100,	99999)" if $breakset =~ /H3K4me3/i;
		$breaks = "c(-999999,	5,	10,	15,	20,	25,	30,	35,	40,	999999)" if $breakset =~ /RRBS/i or $breakset =~ /meth/i;
		$breaks = "c(-999999,	0.5,	0.10,	0.15,	0.20,	0.25,	0.30,	0.35,	0.40,	999999)" if $breakset =~ /RRBS/i or $breakset =~ /meth_dec/i;
		$breaks = "c(0.5,	1,	1.5,	2,	2.5,	3,	3.5,	4,	MAX)" if $breakset =~ /GROSEQ/i;
		$breaks = "c(-0.5,	0.5,	1.5)" if $breakset =~ /hy\w+_pos/i;
		$breaks = "c(2,4,8,16,32,64,128,256,MAX)" if $breakset =~ /snoRNA/i;
	if (not defined($breaks)) {
		print "Breaks of breakset $breakset undefined: Using default breaks (12)\n";
		$breaks = "12";
	}
	return($breaks);
}

sub process_heatmapFile {
	my ($input) = @_;
	my %data;
	my $ncol;
	open (my $in, "<", $input) or die "Cannot read from $input: $!\n";
	while (my $line = <$in>) {
		chomp($line);
		
		# Next if there is a blank space or header
		next if $line =~ /^\n$/;
		next if $line =~ /\#/;

		# Get name and value array
		my ($name2, @value) = split("\t", $line);

		my $name = convert_Name($name2);

		my $valueCount = @value;
		if (not defined($ncol)) {
			$ncol = @value;
			$ncol = 2 if $ncol == 1;
		}
		$ncol = @value if $ncol < @value;

		if (not $opt_b) {
			die "$input: Column number ncol ($ncol) is not identical between data ($valueCount)\n" if defined($ncol) and scalar(@value) > 1 and ($ncol != scalar @value);
			die "$input: Column number ncol ($ncol-1) is not identical between data ($valueCount)\n" if defined($ncol) and scalar(@value) == 1 and ($ncol-1 != scalar @value);
		}

		foreach my $values (@value) {
			$data{$name}{total} += $values if $values =~ /^\-?\d+\.?\d*$/;
		}
		@{$data{$name}{value}} = @value;
		if (defined($opt_s) and $opt_s == 1) {
			$data{$name}{total} = "9999999" if not defined($data{$name}{total});
		}
		else {
			$data{$name}{total} = "-9999999" if not defined($data{$name}{total});
		}

	}

	if ($opt_b) {
		foreach my $name (keys %data) {
			for (my $i = 0; $i < $ncol; $i++) {
				$data{$name}{value}[$i] = "NA" if not defined($data{$name}{value}[$i]);
			}
		}
	}
	return(\%data, $ncol);
}

sub get_cluster {
	my ($clusterFile) = @_;
	my %clusterName;
	my @clusterName;
	open (my $in, "<", $clusterFile) or die "Cannot read from $clusterFile: $!\n";
	while (my $line = <$in>) {
		chomp($line);
		my ($name2) = split("\t", $line);
		my $name = convert_Name($name2);

		$clusterName{$name} = 1;
		push(@clusterName, $name);
	}
	close $in;
	return(\@clusterName, \%clusterName);
}

sub sort_heatmap {
	my ($data, $clusterNameHash, $clusterNameArr, $clusterFile, $outName, $ncol, $dataFile) = @_;
	my %data = %{$data};

	# Sorting
	my @clusterName;
	if (defined($clusterFile) or (defined($opt_s) and $opt_s == 0)) {
		@clusterName = @{$clusterNameArr};# if defined($clusterFile);
	}

	# If clusterFile does not exist, cluster by default high-low or user-defined sorting.
	else {
		@clusterName = sortDescending(\%data) if not defined($opt_s); # Default
		@clusterName = sortAscending(\%data) if defined($opt_s) and $opt_s == 1;
		@clusterName = sortKmeans(\%data, $ncol, $dataFile) if defined($opt_s) and $opt_s == 2;

	}

	my $total = (keys %data);
	my $nrow  = @clusterName;
	my $skip  = $total - $nrow;
	my $Rdata;
	
	open (my $out, ">", "$outName\.sorted") or die "Cannot write to $outName\.sorted: $!\n";
	for (my $i = 0; $i < @clusterName; $i++) {
		my $name = $clusterName[$i];
		my @value;

		# If name does not exist in %data then print the data of that name as all (NA)
		if (not defined($data{$name}{value})) {
			for (my $i = 0; $i < $ncol; $i++) {
				push(@value, "NA");
			}
		}

		# Ncol record value per data. If values of all data are not consistent then die.
		else {
			@value = @{$data{$name}{value}};
		}

		if (not defined($data{$name}{total})) {
	                if (defined($opt_s) and $opt_s == 1) {
	                        $data{$name}{total} = "9999999";
	                }
	                else {
	                        $data{$name}{total} = "-9999999";
	                }
		}
		print $out "$name\t$data{$name}{total}\t";
		my @tempValue;
		for (my $i = 0; $i < @value; $i++) {
			my $tempValue = $value[$i];
			$tempValue = "$tempValue, $tempValue" if @value == 1;
			print $out "$tempValue";
			print $out "\t" if $i != @value - 1;
			push(@tempValue, $tempValue);
		}
		print $out "\n";
		@value = @tempValue;
	
		# Store value into R array format
		# $name -> c(\@value)
		my $Rvalue = R_toolbox::newRArray(\@value, $name);
		$Rdata .= "$Rvalue\n";
	}
	close $out;


	# R arrays that store name and matrix
	my $Rnames = R_toolbox::newRArray(\@clusterName, "name", "with_quote");
	my $RdataBig = R_toolbox::newRArray(\@clusterName, "sample");

	return($Rdata, $Rnames, $RdataBig, $nrow);
}

sub compress_pdf_to_png {

	my ($outName) = @_;
	my $cmd1 = "cpdf $outName.pdf -hflip -o $outName.2 > /dev/null 2>&1 && cpdf $outName.2 -mediabox \"0pt 0pt 451pt 452pt\" -o $outName.3 > /dev/null 2>&1 && cpdf $outName.3 -hflip -o $outName.2 > /dev/null 2>&1";
	my $cmd2 = "convert -density 500 $outName.2 -trim -quality 100 -depth 8 $outName.png > /dev/null 2>&1";
	#my $cmd2 = "convert -density 400 $outName -trim -quality 100 -depth 8 $outName\_temp.png > /dev/null 2>&1";
	system($cmd1) == 0 or die "Failed to run $cmd1: $!\n";
	system($cmd2) == 0 or die "Failed to run $cmd2: $!\n";
	unlink "$outName.2";
	unlink "$outName.3";
}

sub sortDescending {
	my ($data) = @_;
	print "Sorted descending\n";
	my %data = %{$data};
	my @clusterName;
	foreach my $name (sort {$data{$b}{total} <=> $data{$a}{total}} keys %data) {
		push(@clusterName, $name);
	}
	return(@clusterName);
}

sub sortAscending {
	my ($data) = @_;
	my %data = %{$data};
	my @clusterName;
	foreach my $name (sort {$data{$a}{total} <=> $data{$b}{total}} keys %data) {
		push(@clusterName, $name);
	}
	return(@clusterName);
}

sub convert_Name {
	my ($name) = @_;

	my $name2 = $name;
	$name2 =~ s/\-/_/g;
	$name2 =~ s/\//\_/g;
	$name2 =~ s/\./\_/g;
	$name2 =~ s/\(/_/g;
	$name2 =~ s/\)/_/g;
	$name2 =~ s/\+/_/g;
	$name2 =~ s/\~/_/g;
	$name2 =~ s/\`/_/g;
	$name2 =~ s/\'/_/g;
	$name2 =~ s/\"/_/g;
	$name2 =~ s/\:/_/g;
	$name2 =~ s/\;/_/g;
	$name2 =~ s/ /_/g;
	$name2 =~ s/\\/_/g;
	$name2 =~ s/\?/_/g;
	$name2 =~ s/\>/_/g;
	$name2 =~ s/\</_/g;
	$name2 =~ s/$/END/;
	$name2 =~ s/^/START/;
	$name2 =~ s/(START)+/START/;
	$name2 =~ s/(END)+/END/;

	return($name2);
}

sub sortKMeans {
}
__END__
sub sortKMeans {
	my ($data, $ncol, $dataFile) = @_;
	for (my $i = 1; $i <= $ncol; $i++) {
		my $cut = $i + 1;
		my $cmd = "cut -f1,$cut $
	}
	my %data = %{$data};
	my @clusterName;
	my $Q = new Thread::Queue;
	for (my $i = 1; $i <= $ncol+1; $i++) {
		my $command = "find_best_K_and_cluster.pl $dataFile.tmp$i";
		$Q -> enqueue($command);
	}
	$Q -> end;
}
