#!/usr/bin/perl

use strict; use warnings;
use mitochy;
use Thread;
use Thread::Queue;

my ($script, $folder, $extension, $thread) = @ARGV;
die "usage: $0 \"script FILENAME script\" <folder> <extension> <thread>\n" unless @ARGV == 4;

my $Q = new Thread::Queue;

my @file = <$folder/*$extension>;

for (my $i = 0; $i < @file; $i++) {
	my $file = $file[$i];
	my $command = "$script";
	$command =~ s/FILENAME/$file/g;
	print "Example: $command\n" if $i == 0;
	$Q -> enqueue($command);
}
$Q -> end;

my @thread;
for (my $i = 0; $i < $thread; $i++) {
	$thread[$i] = threads->create(\&worker, $i, $Q);
}
for (my $i = 0; $i < $thread; $i++) {
	$thread[$i]->join;
}

sub worker {
	my ($number, $queue) = @_;
	my $tid = threads->tid;
	
	while ($queue->pending) {
		my $command = $queue->dequeue;
		`$command`;
	}
	return;

}
