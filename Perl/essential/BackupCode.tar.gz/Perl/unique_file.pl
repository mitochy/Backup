#!/usr/bin/perl

use strict; use warnings;

my ($input) = @ARGV;
die "\nThis script removes all non-unique line\nusage: $0 <input>\n\n" unless @ARGV;

my %line;
my $lineNumber  = 0;
open (my $in, "<", $input) or die "Cannot read from $input: $!\n";
open (my $out, ">", "$input.unique") or die "Cannot write to $input.unique: $!\n";
while (my $line = <$in>) {
        chomp($line);
        $lineNumber ++;
        $line{$line} = $lineNumber;
}
close $in;

foreach my $line (sort {$line{$a} <=> $line{$b}} keys %line) {
        print $out "$line\n";
}

my $removed = $lineNumber - (keys %line);
print "Removed $removed out of $lineNumber\n";
